# Gogh themes (source)

This repo can import the Gogh theme collection into MATE Terminal `dconf` profile snippets.

- Upstream: `https://github.com/Gogh-Co/Gogh`
- Upstream commit used during initial import: `50b3da841801eef270522274b578fc4ee57fd4e3`
- License: MIT (see `sources/gogh/LICENSE`)

Importer:

- `scripts/import-gogh-to-mate-terminal.py`

