# sandy-konsole (source attribution)

Upstream:

- https://github.com/SaeedBaig/sandy-konsole

Pinned upstream commit (local import baseline):

- `876406bc97123ac59944ec84a49e59b9a82b0bfd`

Converted MATE Terminal profile snippets:

- `mate-terminal/schemes/konsole/community-saeedbaig/kon-sandy.dconf`

License: MIT (see `sources/konsole-community/sandy-konsole/LICENSE`).
