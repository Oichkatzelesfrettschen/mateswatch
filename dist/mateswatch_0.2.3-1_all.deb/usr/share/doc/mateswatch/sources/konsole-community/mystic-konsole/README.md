# mystic-konsole (source attribution)

Upstream:

- https://github.com/SaeedBaig/mystic-konsole

Pinned upstream commit (local import baseline):

- `d9036ade16a926b49e28d135e2d719f69295cd21`

Converted MATE Terminal profile snippets:

- `mate-terminal/schemes/konsole/community-saeedbaig/kon-mystic.dconf`

License: MIT (see `sources/konsole-community/mystic-konsole/LICENSE`).
