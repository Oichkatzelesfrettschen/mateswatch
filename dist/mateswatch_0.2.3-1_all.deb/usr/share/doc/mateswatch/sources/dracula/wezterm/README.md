# Dracula for WezTerm (official)

Upstream:
- Repo: `https://github.com/dracula/wezterm`
- Commit: `0db525a46b5242ee15fd4a52f887e172fbde8e51`
- License: MIT (`LICENSE`)

Vendored input (minimal):
- `dracula.toml`

This file is used to generate MATE Terminal profiles under:
- `mate-terminal/schemes/brands/dracula/`

