# mateswatch stats

- Profiles indexed: **2330**
- Duplicate fingerprints: **585**

## By type

- WZT: 1001
- GOG: 362
- B16: 299
- ALA: 231
- B24: 184
- KTY: 169
- CTP: 68
- KON: 13
- DRC: 3

## Vibe tags (global)

- Dark: 1892
- HighC: 1732
- Vivid: 1722
- Cool: 1097
- Warm: 1046
- Muted: 576
- MedC: 444
- Light: 438
- Neutral: 187
- LowC: 154
- Pastel: 32

