# alacritty-themes (source attribution)

Upstream:

- https://github.com/rajasegar/alacritty-themes

This repository vendors **converted MATE Terminal profile snippets** generated from `alacritty-themes/themes/*.toml`.

Pinned upstream commit (local import baseline):

- `a6f1cbc9c6c6a6ff2bc2ebe83e176e5a959ca421`

License: MIT (see `sources/alacritty-themes/LICENSE`).
