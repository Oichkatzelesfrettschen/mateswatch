# wezterm (source attribution)

Upstream:

- https://github.com/wez/wezterm

This repository vendors **converted MATE Terminal profile snippets** generated from:

- `wezterm/docs/colorschemes/data.json` → `mate-terminal/schemes/wezterm/`

Pinned upstream commit (local import baseline):

- `d3b0fdad453e8b5f12b583c5d6849b33d975c19c`

License: MIT (see `sources/wezterm/LICENSE`).
