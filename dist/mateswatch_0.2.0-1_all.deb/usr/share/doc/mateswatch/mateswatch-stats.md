# mateswatch stats

- Profiles indexed: **2260**
- Duplicate fingerprints: **580**

## By type

- WZT: 1001
- GOG: 362
- B16: 299
- ALA: 231
- B24: 184
- KTY: 169
- KON: 13
- UNK: 1

## Vibe tags (global)

- Dark: 1839
- Vivid: 1705
- HighC: 1662
- Warm: 1042
- Cool: 1033
- Muted: 523
- MedC: 444
- Light: 421
- Neutral: 185
- LowC: 154
- Pastel: 32

