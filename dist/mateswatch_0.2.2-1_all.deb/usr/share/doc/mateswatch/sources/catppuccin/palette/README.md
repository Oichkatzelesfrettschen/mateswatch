# Catppuccin palette (pinned)

Upstream:
- Repo: `https://github.com/catppuccin/palette`
- Tag: `v1.7.1`
- Commit: `92708db0a438b0ed16bc48c3be7e74e2e1620aac`
- License: MIT (`LICENSE`)

Vendored input:
- `palette.json`

This file is used to convert Catppuccin GNOME Terminal → MATE Terminal profiles.

