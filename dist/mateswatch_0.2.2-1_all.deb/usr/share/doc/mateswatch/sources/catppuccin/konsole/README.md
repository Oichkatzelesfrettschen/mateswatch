# Catppuccin Konsole (source attribution)

Upstream:

- https://github.com/catppuccin/konsole

Pinned upstream commit (local import baseline):

- `3b64040e3f4ae5afb2347e7be8a38bc3cd8c73a8`

Converted MATE Terminal profile snippets:

- `mate-terminal/schemes/konsole/brands/kon-catppuccin-frapp.dconf`
- `mate-terminal/schemes/konsole/brands/kon-catppuccin-latte.dconf`
- `mate-terminal/schemes/konsole/brands/kon-catppuccin-macchiato.dconf`
- `mate-terminal/schemes/konsole/brands/kon-catppuccin-mocha.dconf`

License: MIT (see `sources/catppuccin/konsole/LICENSE`).
