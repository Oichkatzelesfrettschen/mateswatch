# konsole-colorschemes (source attribution)

Upstream:

- https://github.com/mounta11n/konsole-colorschemes

Pinned upstream commit (local import baseline):

- `eb6a7d683d5e12b2b58b78d95b28102f6eb67aec`

Converted MATE Terminal profile snippets:

- `mate-terminal/schemes/konsole/community/`

License: MIT (see `sources/konsole-community/konsole-colorschemes/LICENSE`).
