# mateswatch stats

- Profiles indexed: **2275**
- Duplicate fingerprints: **581**

## By type

- WZT: 1001
- GOG: 362
- B16: 299
- ALA: 231
- B24: 184
- KTY: 169
- KON: 13
- CTP: 12
- DRC: 3
- UNK: 1

## Vibe tags (global)

- Dark: 1851
- Vivid: 1709
- HighC: 1677
- Warm: 1046
- Cool: 1041
- Muted: 534
- MedC: 444
- Light: 424
- Neutral: 188
- LowC: 154
- Pastel: 32

