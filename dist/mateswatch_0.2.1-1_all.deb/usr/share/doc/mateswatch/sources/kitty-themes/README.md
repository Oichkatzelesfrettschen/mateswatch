# kitty-themes (source attribution)

Upstream:

- https://github.com/dexpota/kitty-themes

This repository vendors **converted MATE Terminal profile snippets** generated from `kitty-themes/themes/*.conf`.

Pinned upstream commit (local import baseline):

- `b1abdd54ba655ef34f75a568d78625981bf1722c`

License: MIT (see `sources/kitty-themes/LICENSE`).
