# Catppuccin for WezTerm (official)

Upstream:
- Repo: `https://github.com/catppuccin/wezterm`
- Commit: `b1a81bae74d66eaae16457f2d8f151b5bd4fe5da`
- License: MIT (`LICENSE`)

Vendored inputs (minimal):
- `dist/catppuccin-{latte,frappe,macchiato,mocha}.toml`

These files are used to generate MATE Terminal profiles under:
- `mate-terminal/schemes/brands/catppuccin/`

