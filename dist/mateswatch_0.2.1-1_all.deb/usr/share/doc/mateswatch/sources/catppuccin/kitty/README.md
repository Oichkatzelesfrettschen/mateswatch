# Catppuccin for kitty (official)

Upstream:
- Repo: `https://github.com/catppuccin/kitty`
- Commit: `b14e8385c827f2d41660b71c7fec1e92bdcf2676`
- License: MIT (`LICENSE`)

Vendored inputs (minimal):
- `themes/{latte,frappe,macchiato,mocha}.conf`

These files are used to generate MATE Terminal profiles under:
- `mate-terminal/schemes/brands/catppuccin/`

