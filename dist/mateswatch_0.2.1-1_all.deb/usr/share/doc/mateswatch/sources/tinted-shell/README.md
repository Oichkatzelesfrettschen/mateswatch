# tinted-shell (source attribution)

Upstream:

- https://github.com/tinted-theming/tinted-shell

This repository vendors **converted MATE Terminal profile snippets** generated from:

- `tinted-shell/scripts/base16-*.sh` → `mate-terminal/schemes/tinted/base16/`
- `tinted-shell/scripts/base24-*.sh` → `mate-terminal/schemes/tinted/base24/`

Pinned upstream commit (local import baseline):

- `4b8579d356de78b4e7af5ea0b6a06a4cb464a016`

License: MIT-style (see `sources/tinted-shell/LICENSE`).
