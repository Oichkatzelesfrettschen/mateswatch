# stone-red-konsole (source attribution)

Upstream:

- https://github.com/SaeedBaig/stone-red-konsole

Pinned upstream commit (local import baseline):

- `b2c230d6353c49c1e77d11e04eb11d08ef69299e`

Converted MATE Terminal profile snippets:

- `mate-terminal/schemes/konsole/community-saeedbaig/kon-stone-red.dconf`

License: MIT (see `sources/konsole-community/stone-red-konsole/LICENSE`).
