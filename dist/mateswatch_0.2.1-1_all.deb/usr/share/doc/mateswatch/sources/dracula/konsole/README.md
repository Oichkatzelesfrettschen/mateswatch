# Dracula Konsole (source attribution)

Upstream:

- https://github.com/dracula/konsole

Pinned upstream commit (local import baseline):

- `d525667c48b37f76aa28df8968e988ba219d4448`

Converted MATE Terminal profile snippets:

- `mate-terminal/schemes/konsole/brands/kon-dracula.dconf`

License: MIT (see `sources/dracula/konsole/LICENSE`).
