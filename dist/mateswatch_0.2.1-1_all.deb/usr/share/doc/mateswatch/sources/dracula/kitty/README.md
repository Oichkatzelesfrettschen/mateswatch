# Dracula for kitty (official)

Upstream:
- Repo: `https://github.com/dracula/kitty`
- Commit: `87717a3f00e3dff0fc10c93f5ff535ea4092de70`
- License: MIT (`LICENSE`)

Vendored input (minimal):
- `dracula.conf`

This file is used to generate MATE Terminal profiles under:
- `mate-terminal/schemes/brands/dracula/`

